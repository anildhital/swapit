// Import Firebase Authentication from firebase.js
import { auth, db, provider } from "./firebase.js";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  onAuthStateChanged,
  signOut,
} from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";

// Prevent multiple redirections
let isRedirecting = false;

// Toggle between login and signup forms
document.getElementById("toggleSignup")?.addEventListener("click", () => {
  document.getElementById("loginForm").style.display = "none";
  document.getElementById("signupForm").style.display = "block";
  document.getElementById("formTitle").innerText = "Sign Up";
});

document.getElementById("toggleLogin")?.addEventListener("click", () => {
  document.getElementById("signupForm").style.display = "none";
  document.getElementById("loginForm").style.display = "block";
  document.getElementById("formTitle").innerText = "Login";
});

// Function to handle login
async function login(event) {
  event.preventDefault();
  const email = document.getElementById("loginEmail")?.value?.trim();
  const password = document.getElementById("loginPassword")?.value;

  if (!email || !password) {
    alert("Please enter email and password");
    return;
  }

  try {
    const userCredential = await signInWithEmailAndPassword(
      auth,
      email,
      password
    );
    localStorage.setItem("user", JSON.stringify(userCredential.user));
    sessionStorage.setItem("redirected", "true");
    window.location.href = "index.html";
  } catch (error) {
    alert("Login failed: " + error.message);
  }
}

// Function to handle Google Sign-In
async function loginWithGoogle(event) {
  event.preventDefault();
  try {
    const result = await signInWithPopup(auth, provider);
    localStorage.setItem("user", JSON.stringify(result.user));
    sessionStorage.setItem("redirected", "true");
    window.location.href = "index.html";
  } catch (error) {
    alert("Google Sign-In failed: " + error.message);
  }
}

// Function to handle sign-up
async function signup(event) {
  event.preventDefault();
  const username = document.getElementById("signupUsername")?.value.trim();
  const email = document.getElementById("signupEmail")?.value.trim();
  const password = document.getElementById("signupPassword")?.value;

  if (!username || !email || !password) {
    alert("Please fill in all fields");
    return;
  }

  try {
    const userCredential = await createUserWithEmailAndPassword(
      auth,
      email,
      password
    );
    localStorage.setItem("user", JSON.stringify(userCredential.user));
    sessionStorage.setItem("redirected", "true");
    window.location.href = "index.html";
  } catch (error) {
    alert("Signup failed: " + error.message);
  }
}

// Prevent continuous page refresh loop
onAuthStateChanged(auth, (user) => {
  const currentPage = window.location.pathname;
  const redirected = sessionStorage.getItem("redirected");

  if (user && currentPage.includes("login.html") && !redirected) {
    sessionStorage.setItem("redirected", "true");
    window.location.href = "index.html";
  } else if (!user && currentPage.includes("index.html") && !redirected) {
    sessionStorage.setItem("redirected", "true");
    window.location.href = "login.html";
  }
});

// Function to handle logout
function logout(event) {
  event.preventDefault();
  signOut(auth)
    .then(() => {
      localStorage.removeItem("user");
      sessionStorage.removeItem("redirected");
      window.location.href = "login.html";
    })
    .catch((error) => {
      alert("Logout failed: " + error.message);
    });
}

// Attach event listeners
document.getElementById("loginBtn")?.addEventListener("click", login);
document.getElementById("signupBtn")?.addEventListener("click", signup);
document
  .getElementById("googleLoginBtn")
  ?.addEventListener("click", loginWithGoogle);
document.getElementById("logoutBtn")?.addEventListener("click", logout);
